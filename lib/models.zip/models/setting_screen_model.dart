class SettingScreenModel {
  String? image;
  String? title;
  String? key;
  Function()? onclick;

  SettingScreenModel({this.image, this.title, this.onclick, this.key});
}
