class PaymentMethodListModel {
  String? image;
  String? title;


  PaymentMethodListModel({this.image, this.title,});
}
