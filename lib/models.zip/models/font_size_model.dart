class FontSizeModel {
  String? fontName;
  num? fontSize;

  FontSizeModel({this.fontName, this.fontSize});
}
